# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: checkout.spec.js >> Checkout >> applies a discount code
- Location: tests/checkout.spec.js:3:3

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#t')
Expected: "Total $45.00"
Received: "Total $50.00"
Timeout:  500ms

Call log:
  - Expect "toHaveText" locator('#t') with timeout 500ms
  - waiting for locator('#t')
    6 × locator resolved to <p id="t">Total $50.00</p>
      - unexpected value "Total $50.00"

```

```yaml
- paragraph: Total $50.00
```

# Test source

```ts
  1  | const { test, expect } = require("@playwright/test");
  2  | test.describe("Checkout", () => {
  3  |   test("applies a discount code", async ({ page }) => {
  4  |     await test.step("Open the shop", async () => { await page.setContent("<h1>Shop</h1><p id=t>Total $50.00</p>"); });
> 5  |     await test.step("Check the total is $45.00", async () => { await expect(page.locator("#t")).toHaveText("Total $45.00", { timeout: 500 }); });
     |                                                                                                 ^ Error: expect(locator).toHaveText(expected) failed
  6  |   });
  7  |   test("shows the cart", async ({ page }) => { await page.setContent("<h1>Cart</h1>"); await expect(page.locator("h1")).toHaveText("Cart"); });
  8  |   let n = 0;
  9  |   test("flaky one", async ({ page }) => { await page.setContent("<b>x</b>"); n++; if (test.info().retry === 0) throw new Error("first try fails"); });
  10 | });
  11 | 
```